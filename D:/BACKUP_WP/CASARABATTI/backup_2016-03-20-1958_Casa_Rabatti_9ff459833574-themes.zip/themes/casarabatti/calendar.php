<div class="wrap">
    <h2>Calendario</h2>
    <div id='calendar'></div>
</div>