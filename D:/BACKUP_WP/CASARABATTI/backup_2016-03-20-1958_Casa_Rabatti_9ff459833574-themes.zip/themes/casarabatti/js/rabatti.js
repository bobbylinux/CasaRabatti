jQuery(document).ready(function(){

  jQuery('#calendar').fullCalendar({
    firstDay: 1,
    events: "../wp-content/themes/casarabatti/process.php",/*function(start, end, timezone, callback) {
      jQuery.ajax({
        url: '../wp-content/themes/casarabatti/process.php',
        dataType: 'json',
        type: 'POST',
        data: 'type=fetch',
        async: false,
        success: function (event) {
          var buildingEvents = jQuery.map(event.d, function (item) {
            return {
              id: item.id,
              title: item.title,
              start: item.start,
              end: item.end,
              allDay: item.allDay
            };
          });

          callback(buildingEvents);
        },
        error: function (data) {
          alert(data);
        }
      });
    },*/
    dayClick: function() {

    }
  })
});

