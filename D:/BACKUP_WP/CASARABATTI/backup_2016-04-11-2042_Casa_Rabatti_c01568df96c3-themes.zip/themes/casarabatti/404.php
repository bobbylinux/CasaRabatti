<?php get_header(); ?>
    <div id="content" role="main">
        <article class="post">
            <h2>Pagina non trovata!</h2>
        </article> <!-- .post  -->
        <hr />
    </div> <!-- #content -->
<?php get_footer(); ?>