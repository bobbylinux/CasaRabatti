<?php

//parametri per email
$mail_mail = "info@casarabatti.it";
$mail_mail = "info@casarabatti.it";
$mail_name = "Casa Rabatti 1823";
$mail_webmaster = "info@casarabatti.it";
$bounce_email = "info@casarabatti.it";
$message_base ="CASA RABATTI 1823<br />Via San Zanobi 48<br />TEL +39 338.1534159<br />MAIL: <a href='mailto:info@casarabatti.it'>info@casarabatti.it</a><br /> WEB: <a href='http://www.casarabatti.it' target='_blank'>WWW.CASARABATTI.IT</a>\n";

//password per inserimento mail
$password = "";

//server smtp
$smtphost = "bulkmailer.mclink.it";

//indirizzo sito
$site_base = "http://www.casarabatti.it/";
$dir_base = "/";
$dir_base_noSlash = "";

$unsuscribeAddress = "http://www.casarabatti.it/sendletter/unsubscribe.php";

?>