/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.plugins.setLang( 'uploadwidget', 'ug', {
	abort: 'يۈكلەشنى ئىشلەتكۈچى ئۈزۈۋەتتى.',
	doneOne: 'ھۆججەت مۇۋەپپەقىيەتلىك يۈكلەندى.',
	doneMany: 'مۇۋەپپەقىيەتلىك ھالدا %1 ھۆججەت يۈكلەندى.',
	uploadOne: 'Uploading file ({percentage}%)...', // MISSING
	uploadMany: 'Uploading files, {current} of {max} done ({percentage}%)...' // MISSING
} );
