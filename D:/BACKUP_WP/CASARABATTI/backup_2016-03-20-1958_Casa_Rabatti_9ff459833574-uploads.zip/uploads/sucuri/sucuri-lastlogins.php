<?php exit(0); ?>
{"user_id":1,"user_login":"admin","user_remoteaddr":"84.253.136.69","user_hostname":"net84-253-136-069.mclink.it","user_lastlogin":"2016-03-05 13:30:58"}
{"user_id":1,"user_login":"admin","user_remoteaddr":"84.253.136.69","user_hostname":"net84-253-136-069.mclink.it","user_lastlogin":"2016-03-06 18:52:41"}
{"user_id":1,"user_login":"admin","user_remoteaddr":"5.88.67.139","user_hostname":"net-5-88-67-139.cust.vodafonedsl.it","user_lastlogin":"2016-03-09 21:12:02"}
