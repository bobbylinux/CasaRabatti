<?php exit(0); ?>
{"user_login":"Roberto Bani","user_password":"","attempt_time":1457554296,"remote_addr":"5.88.67.139","user_agent":"Mozilla\/5.0 (Macintosh; Intel Mac OS X 10.11; rv:44.0) Gecko\/20100101 Firefox\/44.0"}
