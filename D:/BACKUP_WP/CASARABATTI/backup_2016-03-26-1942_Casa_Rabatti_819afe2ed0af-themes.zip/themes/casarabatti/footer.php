        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <span class="copyright"><a href="http://www.globeit.it" target="_blank">Copyright &copy; Globe-it 2016</a></span>
                    </div>
                    <div class="col-md-4">
                        <ul class="list-inline social-buttons">
                            <li><a href="https://www.facebook.com/Casa-Rabatti-1015721258487629" target="_black"><i class="fa fa-facebook"></i></a>
                            </li>
                            <li><a href="#"><i class="fa fa-tripadvisor"></i></a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <ul class="list-inline quicklinks">
                            <li><a href="#">Privacy Policy</a>
                            </li>
                            <li><a href="#">Terms of Use</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>
        <?php wp_footer(); ?>
    </body>
</html>