<?php

$interessi = array();

if (isset($_POST['oggetto'])) {

    $interessi = explode(',',$_POST['interessi']);

    $data['success'] = true;
    $data['message'] = $_POST['interessi'];
}


echo json_encode($interessi);