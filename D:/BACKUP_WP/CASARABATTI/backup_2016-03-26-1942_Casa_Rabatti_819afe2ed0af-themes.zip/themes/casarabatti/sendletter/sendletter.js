jQuery(document).ready(function(){

    jQuery(document).on("submit","#form-newsletter",function(event){
        event.preventDefault();

        var chkArray = [];

        /* look for all checkboes that have a class 'chk' attached to it and check if it was checked */
        jQuery(".chk:checked").each(function() {
            chkArray.push(jQuery(this).val());
        });

        /* we join the array separated by the comma */
        var selected;
        selected = chkArray.join(',');

        var formData = {
            'oggetto'               : jQuery("#subject-newsletter").val(),
            'testo'                 : jQuery("#text-newsletter").val(),
            'interessi'             : selected
        };


        // process the form
        jQuery.ajax({
            type        : 'POST', // define the type of HTTP verb we want to use (POST for our form)
            url         : '../wp-content/themes/casarabatti/sendletter/sendletterSubmit.php', // the url where we want to POST
            data        : formData, // our data object
            dataType    : 'json', // what type of data do we expect back from the server
            encode          : true
        })
            // using the done promise callback
            .done(function(data) {

               console.log(data);
            });

    });

});