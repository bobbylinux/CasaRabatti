    <?php
// parametri del database
$db_host = "localhost";
$db_user = "caisse";
$db_password = "nDF8wSUe7dLqx3pF";
$db_name = "caisse";

//parametri per email
$mail_mail = "webmaster@globeit.it";
$mail_mail = "info@caisse.it";
$mail_name = "Holistic Remedies";
$mail_webmaster = "webmaster@globeit.it";
$bounce_email = "info@caisse.it";
$message_base ="HOLISTIC REMEDIES<br />Via Piave, 99 - 50068 Rufina (FI)<br />TEL +39 0558395388<br />MAIL: <a style='color: white' href='mailto:info@caisse.it'>INFO@CAISSE.IT</a><br /> WEB: <a style='color: white' href='http://www.holisticremedies.it' target='_blank'>WWW.HOLISTICREMEDIES.IT</a>\n";
$image_testatamail = "http://www.holisticremedies.it/sendletter/testataMAIL.jpg";

//password per inserimento mail
$password = "";

//server smtp
$smtphost = "bulkmailer.mclink.it";

//indirizzo sito
$site_base = "http://www.holisticremedies.it/";
$dir_base = "/";
$dir_base_noSlash = "";

$unsuscribeAddress = "http://www.holisticremedies.it/sendletter/unsubscribe.php";

?>