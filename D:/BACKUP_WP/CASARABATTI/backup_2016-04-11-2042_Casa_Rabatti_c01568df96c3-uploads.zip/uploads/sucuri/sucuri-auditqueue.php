<?php
// datastore=auditqueue;
// created_on=1456137597;
// updated_on=1460397275;
exit(0);
?>
2bbb64d8a0a5a5aa163ccb9bb45622e6:{"created_at":1457167259,"message":null}
76c30594de376c78ca17b2cd18907481:{"created_at":1457189451,"message":"Notice: admin, 84.253.136.69; Page was created; identifier: 227; name: Cookie Policy"}
2e5f286b9be66710160d677b3bc73342:{"created_at":1457227699,"message":null}
764c0fd812afaa846ae545a128d45d58:{"created_at":1457286730,"message":null}
ff6c00eda63c800ebe44afefb270e3f9:{"created_at":1457286756,"message":"Notice: 84.253.136.69; User authentication succeeded: admin"}
c620fc3fae3c0a872d6ecb799b25ed64:{"created_at":1457306629,"message":"Warning: 195.110.146.217; Post deleted; identifier: 84"}
d5bc8f0b02ba414dee8bd33071f67498:{"created_at":1457314800,"message":null}
913ff9e28d072726e79490981a01634e:{"created_at":1457388627,"message":"Warning: 127.0.0.1; Post deleted; identifier: 84"}
47547a08a49d9a6909b4b75bf635c936:{"created_at":1457388858,"message":null}
478862ea2185ad5fbefd6f0ad5d0f8bd:{"created_at":1457554291,"message":"Error: 5.88.67.139; User authentication failed: Roberto Bani"}
dbcc27a6410b2de3a426c045e61a22a0:{"created_at":1457554317,"message":"Notice: 5.88.67.139; User authentication succeeded: admin"}
d5d610cca4ce3306c66afa1664efc741:{"created_at":1457554632,"message":"Notice: admin, 5.88.67.139; Post was updated; identifier: 231; name: I Partners"}
ad48e6dcb116573ecdc94b22ca8428ed:{"created_at":1459072052,"message":null}
8e0481780c43e07b51d17e55c8a41fbd:{"created_at":1459110278,"message":"Notice: 192.168.1.2; User authentication succeeded: admin"}
f90ba7269ca2c8b52ef990fe0a360cfa:{"created_at":1459449580,"message":"Warning: 127.0.0.1; Post deleted; identifier: 239"}
f59c369bb788ca642e9d19e371d6f10c:{"created_at":1459449585,"message":"Warning: 127.0.0.1; Post deleted; identifier: 241"}
12195ede3fdf9e0aedcbdb6ab53bd069:{"created_at":1459449594,"message":null}
5952687368e367ffeaab530a04b038b0:{"created_at":1459497851,"message":null}
c27f5c0e3f13fea1efc88dd2d81bc890:{"created_at":1459584674,"message":null}
18f0ccdfbc5f74e8b7aadfb33574252d:{"created_at":1459677202,"message":null}
dc282cc92c3ac03ad60a7f15dbd93475:{"created_at":1459682241,"message":"Notice: admin, 192.168.1.2; Post was updated; identifier: 11; name: La Struttura"}
787f887c990fbf9d942fd6d21ce5f2ee:{"created_at":1459682441,"message":"Notice: admin, 192.168.1.2; Post was updated; identifier: 18; name: Dove Siamo"}
40b383e2260a8efb47c8f5eacd355cfe:{"created_at":1459682497,"message":"Notice: admin, 192.168.1.2; Post was updated; identifier: 18; name: Dove Siamo"}
70aa1a6ba6a412b3f5a4fc921106f3c4:{"created_at":1459694287,"message":null}
ce40639d8deb61e2687e168a297d9bba:{"created_at":1459790162,"message":null}
fe7cdba093f1f54a25d170cf8d04af17:{"created_at":1459897055,"message":null}
7dde123f9f9e556e1992175a70d46d3d:{"created_at":1459968886,"message":null}
e802d46eefdb8b7645e70e158508522d:{"created_at":1460188791,"message":null}
73d6f9558c309d2ea29e75f94a4f6dc4:{"created_at":1460199228,"message":"Notice: admin, 192.168.1.2; Post was updated; identifier: 231; name: I Partners"}
7bde057901c22197e4320c97de057edf:{"created_at":1460199292,"message":"Notice: admin, 192.168.1.2; Post was updated; identifier: 231; name: I Partners"}
097e46c60987c8f7fd749dd65c2627ff:{"created_at":1460236212,"message":null}
ff070194b214686d5ba937b4639b9242:{"created_at":1460242893,"message":"Notice: admin, 192.168.1.2; Post was updated; identifier: 231; name: I Partners"}
046324d868e25327298eb1111d689fc4:{"created_at":1460242956,"message":"Notice: admin, 192.168.1.2; Post was updated; identifier: 231; name: I Partners"}
7fa58fb2c3d15a0ac8e5bda2d6af96b1:{"created_at":1460242988,"message":"Notice: admin, 192.168.1.2; Post was updated; identifier: 231; name: I Partners"}
427cfc84e0b36d307da5f6048f408d67:{"created_at":1460243190,"message":"Notice: admin, 192.168.1.2; Post was updated; identifier: 231; name: I Partners"}
99d211f8dd86099ecbd42cf03b974a78:{"created_at":1460243308,"message":"Notice: admin, 192.168.1.2; Post was updated; identifier: 231; name: I Partners"}
514cbc8d1a23978697b2b86947b7efca:{"created_at":1460243333,"message":"Notice: admin, 192.168.1.2; Post was updated; identifier: 231; name: I Partners"}
12044830ea985eaf4a653a5ceb13cabd:{"created_at":1460243409,"message":"Notice: admin, 192.168.1.2; Post was updated; identifier: 231; name: I Partners"}
de8ded8a6fa6d5a6f4a9a27025dbad64:{"created_at":1460248495,"message":null}
7144887460110ca718192a295eb62a7d:{"created_at":1460288605,"message":"Notice: admin, 192.168.1.2; Post was updated; identifier: 231; name: I Partners"}
ea54ef406da04790bbc3ebee30c042f5:{"created_at":1460288683,"message":"Notice: admin, 192.168.1.2; Post was updated; identifier: 231; name: I Partners"}
756ce3a36177c379780449ee99d09b81:{"created_at":1460288763,"message":"Notice: admin, 192.168.1.2; Post was updated; identifier: 231; name: I Partners"}
0e7f098bddd04fd64d79757dfd28af20:{"created_at":1460291775,"message":null}
efac45e6eca332496b28e88b704e8179:{"created_at":1460312661,"message":"Warning: admin, 192.168.1.2; Plugin activated: Polylang (v1.8.5; polylang\/polylang.php)"}
dc14a42766e3cf2ead9cc051586d6469:{"created_at":1460314607,"message":"Warning: admin, 192.168.1.2; Plugin activated: qTranslate-X (v3.4.6.4; qtranslate-x\/qtranslate.php)"}
0f1b87f76ad5fc3f8ecbe558068a38fc:{"created_at":1460316342,"message":"Notice: admin, 192.168.1.2; Post was updated; identifier: 11; name: [:it]La Struttura[:en]The Location[:]"}
1dd610712d709089a417fbd4fd6c9007:{"created_at":1460317761,"message":"Notice: admin, 192.168.1.2; Nav_menu_item (private to published); identifier: 274; name: "}
91ed9a4f19118f066a771cba5ea53140:{"created_at":1460317767,"message":"Notice: admin, 192.168.1.2; Nav_menu_item (private to published); identifier: 275; name: "}
422a602f6ec4e418dfbc96c3e421ae1f:{"created_at":1460396796,"message":"Notice: 192.168.1.2; User authentication succeeded: admin"}
f8296b2f6bdf8d316b0bc99db2d9e73e:{"created_at":1460397053,"message":"Notice: admin, 192.168.1.2; Post was updated; identifier: 16; name: I Locali"}
693f71ecd8d5af7070b562022b6a84c6:{"created_at":1460397122,"message":"Notice: admin, 192.168.1.2; Post was updated; identifier: 16; name: I Locali"}
460bce41bc39cf840769d2d1fd4f92f8:{"created_at":1460397194,"message":"Notice: admin, 192.168.1.2; Page was created; identifier: 281; name: [:it]Camere Economiche[:]"}
d797ca1a828862528f717e523c190ece:{"created_at":1460397270,"message":"Notice: admin, 192.168.1.2; Post was updated; identifier: 16; name: I Locali"}
